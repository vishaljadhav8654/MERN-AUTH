const express = require("express"); 

const {  
    registerUser,
    loginUser,
    updateUser,
    getAllUsers,
    getUserById,
} = require("../controller/authController");

const router = express.Router(); 

router.post("/register", registerUser); 
router.post("/login", loginUser); 
router.put("/update/:id", updateUser);
router.get("/users", getAllUsers);
router.get("/user/:id", getUserById);

module.exports = router;